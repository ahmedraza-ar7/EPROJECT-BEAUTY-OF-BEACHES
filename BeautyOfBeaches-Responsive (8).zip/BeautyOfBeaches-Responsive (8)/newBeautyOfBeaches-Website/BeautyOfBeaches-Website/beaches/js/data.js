/* BeautyOfBeaches data store (mirrored in data/beaches.json) */
window.BEACHES = [
  { id: 1, zone: "east", name: "Whitehaven Beach", country: "Australia", img: "beach card 1.jpg", best: "Aug – Oct", rating: 4.9, desc: "Famous for its 7 km of pure white silica sand and crystal-clear turquoise waters in the Whitsunday Islands.", acts: ["Sailing", "Snorkeling", "Hill Inlet lookout"] },
  { id: 2, zone: "east", name: "Bora Bora", country: "French Polynesia", img: "beach card 2.jpg", best: "May – Oct", rating: 4.9, desc: "A stunning lagoon ringed by coral reef with Mount Otemanu rising behind overwater bungalows.", acts: ["Lagoon tours", "Shark & ray snorkel", "Jet ski"] },
  { id: 3, zone: "east", name: "Boracay White Beach", country: "Philippines", img: "images/east.jpg", best: "Nov – May", rating: 4.7, desc: "Powder-soft sand and some of the most dramatic sunsets in Asia, with lively beach-front cafés.", acts: ["Paraw sailing", "Island hopping", "Sunset cruises"] },
  { id: 4, zone: "east", name: "Phra Nang Beach", country: "Thailand", img: "beach card 3.jpg", best: "Nov – Apr", rating: 4.8, desc: "Towering limestone cliffs, hidden caves and emerald waters on the Railay peninsula in Krabi.", acts: ["Rock climbing", "Kayaking", "Cave exploring"] },
  { id: 5, zone: "north", name: "Anse Source d'Argent", country: "Seychelles", img: "beach card 4.jpg", best: "Apr – May", rating: 4.9, desc: "Sculpted granite boulders frame calm shallow lagoons — one of the most photographed beaches on Earth.", acts: ["Photography", "Snorkeling", "Cycling La Digue"] },
  { id: 6, zone: "north", name: "Navagio Beach", country: "Greece", img: "beach card 5.jpg", best: "May – Sep", rating: 4.8, desc: "The legendary Shipwreck Cove on Zakynthos, enclosed by white cliffs and electric-blue water.", acts: ["Boat trips", "Cliff viewpoint", "Swimming"] },
  { id: 7, zone: "north", name: "Lofoten Beaches", country: "Norway", img: "beach card 6.jpg", best: "Jun – Aug", rating: 4.6, desc: "Arctic beaches with Caribbean-coloured water beneath jagged peaks and the midnight sun.", acts: ["Surfing", "Hiking", "Northern lights"] },
  { id: 8, zone: "north", name: "Cala Macarella", country: "Spain", img: "beach card 7.jpg", best: "Jun – Sep", rating: 4.7, desc: "A pine-fringed cove on Menorca with sheltered, glass-clear Mediterranean water.", acts: ["Coastal walks", "Paddle boarding", "Snorkeling"] },
  { id: 9, zone: "west", name: "Twelve Apostles", country: "Australia", img: "beach card 8.jpg", best: "Dec – Feb", rating: 4.8, desc: "Limestone sea stacks rising from the Southern Ocean along the Great Ocean Road — magical at sunset.", acts: ["Scenic drive", "Helicopter flights", "Sunset viewing"] },
  { id: 10, zone: "west", name: "Kaanapali Beach", country: "Hawaii, USA", img: "beach card 9.jpg", best: "Apr – Oct", rating: 4.7, desc: "Three miles of golden sand on Maui, perfect for water sports and cliff diving at Black Rock.", acts: ["Cliff diving", "Whale watching", "Surfing"] },
  { id: 11, zone: "west", name: "Grace Bay", country: "Turks & Caicos", img: "beach card 10.jpg", best: "Dec – Apr", rating: 4.9, desc: "Repeatedly voted the world's best beach for its calm, luminous water and protected reef.", acts: ["Reef diving", "Kiteboarding", "Spa resorts"] },
  { id: 12, zone: "west", name: "Kuta Beach", country: "Bali, Indonesia", img: "barch card 11.jpg", best: "Apr – Oct", rating: 4.5, desc: "Bali's vibrant surf beach with golden sand, lively nightlife and unforgettable sunsets.", acts: ["Surf lessons", "Beach clubs", "Markets"] },
  { id: 13, zone: "south", name: "Maldives Atolls", country: "Maldives", img: "beach card 12.jpg", best: "Nov – Apr", rating: 5.0, desc: "A tropical paradise of blue lagoons, coral islands and luxury overwater villas.", acts: ["Diving", "Dolphin cruises", "Overwater stays"] },
  { id: 14, zone: "south", name: "Clifton Beach", country: "South Africa", img: "beach card 13.jpg", best: "Nov – Mar", rating: 4.6, desc: "Four sheltered coves below Lion's Head in Cape Town, framed by granite boulders.", acts: ["Sunbathing", "Table Mountain views", "Picnics"] },
  { id: 15, zone: "south", name: "Unawatuna Beach", country: "Sri Lanka", img: "beach card 14.jpg", best: "Dec – Apr", rating: 4.6, desc: "A palm-lined crescent bay with calm water, turtles and coral close to the shore.", acts: ["Turtle spotting", "Snorkeling", "Galle Fort visit"] },
  { id: 16, zone: "south", name: "Great Barrier Reef Cays", country: "Australia", img: "beach card 15.jpg", best: "Jun – Oct", rating: 4.9, desc: "Tiny sandy cays sitting atop the world's largest coral reef system, alive with marine life.", acts: ["Scuba diving", "Glass-bottom boats", "Reef walks"] },

// More West Zone Beaches

// More South Zone Beaches
// {
//     id: 18,
//     zone: "south",
//     name: "Bondi Beach",
//     country: "Australia",
//     img: "beach card 20.jpg",
//     best: "Sep – Nov",
//     rating: 4.9,
//     desc: "Australia's iconic beach, famous for its golden sand, surfing culture and beautiful coastal walking trails.",
//     acts: ["Surfing", "Swimming", "Coastal walks"]
// },
// {
//     id: 19,
//     zone: "south",
//     name: "Boulders Beach",
//     country: "South Africa",
//     img: "beach card 21.jpg",
//     best: "Nov – Mar",
//     rating: 4.8,
//     desc: "A unique beach surrounded by giant granite boulders and famous for its African penguin colony.",
//     acts: ["Penguin watching", "Photography", "Swimming"]
// },
// {
//     id: 20,
//     zone: "south",
//     name: "Pink Beach",
//     country: "Indonesia",
//     img: "beach card 22.jpg",
//     best: "Apr – Nov",
//     rating: 4.9,
//     desc: "A spectacular beach with naturally pink sand, clear blue water and colourful coral reefs.",
//     acts: ["Snorkeling", "Scuba diving", "Photography"]
// },
// {
//     id: 21,
//     zone: "south",
//     name: "Hiriketiya Beach",
//     country: "Sri Lanka",
//     img: "beach card 23.jpg",
//     best: "Nov – Apr",
//     rating: 4.7,
//     desc: "A beautiful horseshoe-shaped bay surrounded by palm trees, tropical greenery and relaxing beach cafés.",
//     acts: ["Surfing", "Swimming", "Yoga"]
// },



];

window.ZONES = {
  east:  { title: "East Zone",  tag: "Sunrise beaches & cultural beauty", img: "images/east.jpg" },
  north: { title: "North Zone", tag: "Scenic shores & cool vibes",        img: "images/north.jpg" },
  west:  { title: "West Zone",  tag: "Golden beaches & vibrant life",     img: "images/west.jpg" },
  south: { title: "South Zone", tag: "Crystal waters & tropical charm",   img: "images/south.jpg" }
};
