/* BeautyOfBeaches — main script (jQuery) */
$(function () {
  // ---------- Preloader ----------
  $(window).on("load", function () { $("#preloader").delay(400).fadeOut(700); });
  setTimeout(function () { $("#preloader").fadeOut(700); }, 3500); // fallback

  // ---------- AOS animations ----------
  if (window.AOS) AOS.init({ duration: 900, once: true, offset: 60 });

  // ---------- Navbar: scroll + click colour + fade menus ----------
  $(window).on("scroll", function () {
    var y = $(this).scrollTop();
    $(".navbar-beach").toggleClass("scrolled", y > 60);
    y > 400 ? $("#toTop").fadeIn(300) : $("#toTop").fadeOut(300);
  });
  $(".navbar-beach .nav-link").on("click", function () {
    $(".navbar-beach .nav-link").removeClass("clicked");
    $(this).addClass("clicked");
  });
  $("#toTop").on("click", function () { $("html, body").animate({ scrollTop: 0 }, 700); });

  // ---------- Visitor counter (localStorage) ----------
  var base = 12840;
  var visits = parseInt(localStorage.getItem("bob_visits") || "0", 10);
  if (!sessionStorage.getItem("bob_counted")) { visits++; localStorage.setItem("bob_visits", visits); sessionStorage.setItem("bob_counted", "1"); }
  $(".visitor-count").each(function () {
    var $el = $(this), target = base + visits;
    $({ n: target - 60 }).animate({ n: target }, { duration: 1500, step: function (v) { $el.text(Math.floor(v).toLocaleString()); } });
  });

  // ---------- Ticker: date, time, location ----------
  var place = "Detecting location…";
  function tick() {
    var d = new Date();
    $("#tk-date").text(d.toLocaleDateString(undefined, { weekday: "long", year: "numeric", month: "long", day: "numeric" }));
    $("#tk-time").text(d.toLocaleTimeString());
    $("#tk-loc").text(place);
  }
  tick(); setInterval(tick, 1000);
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function (p) {
      var lat = p.coords.latitude.toFixed(3), lon = p.coords.longitude.toFixed(3);
      place = "Lat " + lat + ", Lon " + lon;
      $.getJSON("https://nominatim.openstreetmap.org/reverse?format=json&lat=" + lat + "&lon=" + lon)
        .done(function (r) { var a = r.address || {}; place = [a.city || a.town || a.village || a.county, a.country].filter(Boolean).join(", ") || place; });
    }, function () { place = "Location unavailable (permission denied)"; });
  } else { place = "Geolocation not supported"; }

  // ---------- Hero slider ----------
  var $slides = $(".hero .slide"), cur = 0;
  if ($slides.length) {
    $slides.each(function (i) { $(".hero-dots").append('<button aria-label="Slide ' + (i + 1) + '"></button>'); });
    function show(i) { cur = (i + $slides.length) % $slides.length; $slides.removeClass("on").eq(cur).addClass("on"); $(".hero-dots button").removeClass("on").eq(cur).addClass("on"); }
    show(0);
    var timer = setInterval(function () { show(cur + 1); }, 5000);
    $(".hero-dots").on("click", "button", function () { clearInterval(timer); show($(this).index()); timer = setInterval(function () { show(cur + 1); }, 5000); });
  }

  // ---------- Beach cards rendering ----------
  function card(b) {
    return '<div class="col-sm-6 col-lg-3 beach-col" data-zone="' + b.zone + '" data-aos="fade-up">' +
      '<div class="beach-card"><div class="thumb"><img src="' + b.img + '" alt="' + b.name + '" loading="lazy">' +
      '<span class="zone-pill">' + b.zone + '</span><span class="rate"><i class="bi bi-star-fill"></i> ' + b.rating + '</span></div>' +
      '<div class="body"><h5>' + b.name + '</h5><div class="loc"><i class="bi bi-geo-alt-fill"></i> ' + b.country + '</div>' +
      '<p>' + b.desc + '</p><div><button class="btn btn-coral btn-coral-sm view-beach" data-id="' + b.id + '">View Details <i class="bi bi-arrow-right"></i></button></div></div></div></div>';
  }
  $("[data-beaches]").each(function () {
    var $c = $(this), zone = $c.data("beaches"), limit = parseInt($c.data("limit") || 99, 10);
    var list = window.BEACHES.filter(function (b) { return zone === "all" || zone === "featured" ? true : b.zone === zone; });
    if (zone === "featured") list = list.filter(function (b) { return [1, 13, 2, 10].indexOf(b.id) > -1; });
    $c.html(list.slice(0, limit).map(card).join(""));
  });

  // Filter + search
  $(".filter-btns").on("click", ".btn", function () {
    $(".filter-btns .btn").removeClass("on"); $(this).addClass("on");
    var z = $(this).data("filter");
    $(".beach-col").each(function () { (z === "all" || $(this).data("zone") === z) ? $(this).fadeIn(400) : $(this).fadeOut(300); });
  });
  $("#beachSearch").on("input", function () {
    var q = $(this).val().toLowerCase();
    $(".beach-col").each(function () { $(this).toggle($(this).text().toLowerCase().indexOf(q) > -1); });
  });

  // Details modal
  $(document).on("click", ".view-beach", function () {
    var b = window.BEACHES.find(function (x) { return x.id == $(this).data("id"); }, this);
    if (!b) return;
    $("#bm-img").attr("src", b.img).attr("alt", b.name);
    $("#bm-title").text(b.name);
    $("#bm-loc").text(b.country + " · " + b.zone.toUpperCase() + " ZONE");
    $("#bm-desc").text(b.desc);
    $("#bm-best").text(b.best);
    $("#bm-rate").text(b.rating + " / 5");
    $("#bm-acts").html(b.acts.map(function (a) { return '<span class="badge-mint d-inline-block">' + a + "</span>"; }).join(""));
    new bootstrap.Modal("#beachModal").show();
  });

  // ---------- Gallery lightbox ----------
  var $g = $(".gal-item"), gi = 0;
  function openLb(i) { gi = (i + $g.length) % $g.length; var $it = $g.eq(gi); $("#lightbox img").hide().attr("src", $it.find("img").attr("src")).fadeIn(300); $(".lb-cap").text($it.find("img").attr("alt")); $("#lightbox").css("display", "flex").hide().fadeIn(300); }
  $g.on("click", function (e) { e.preventDefault(); openLb($g.index(this)); });
  $(".lb-close").on("click", function () { $("#lightbox").fadeOut(300); });
  $(".lb-prev").on("click", function () { openLb(gi - 1); });
  $(".lb-next").on("click", function () { openLb(gi + 1); });
  $(document).on("keydown", function (e) { if ($("#lightbox").is(":visible")) { if (e.key === "Escape") $("#lightbox").fadeOut(300); if (e.key === "ArrowLeft") openLb(gi - 1); if (e.key === "ArrowRight") openLb(gi + 1); } });

  // ---------- Counters ----------
  var counted = false;
  function runCounters() {
    if (counted || !$(".stat .num").length) return;
    if ($(window).scrollTop() + $(window).height() > $(".stat").first().offset().top) {
      counted = true;
      $(".stat .num").each(function () { var $t = $(this), to = +$t.data("to"); $({ n: 0 }).animate({ n: to }, { duration: 2000, step: function (v) { $t.text(Math.ceil(v) + ($t.data("suffix") || "")); } }); });
    }
  }
  $(window).on("scroll", runCounters); runCounters();

  // ---------- Star rating ----------
  $(".star-rate i").on("mouseenter click", function (ev) {
    var v = $(this).index() + 1;
    $(this).parent().find("i").each(function (i) { $(this).toggleClass("on", i < v).toggleClass("bi-star-fill", i < v).toggleClass("bi-star", i >= v); });
    if (ev.type === "click") $("#rating").val(v);
  });

  // ---------- Forms (validated, saved to localStorage) ----------
  $("form.save-form").on("submit", function (e) {
    e.preventDefault();
    var f = this, $f = $(f);
    if (!f.checkValidity()) { $f.addClass("was-validated"); return; }
    var key = $f.data("store"), data = {};
    $f.serializeArray().forEach(function (x) { data[x.name] = x.value; });
    data.date = new Date().toLocaleString();
    var all = JSON.parse(localStorage.getItem(key) || "[]"); all.unshift(data); localStorage.setItem(key, JSON.stringify(all));
    f.reset(); $f.removeClass("was-validated"); $(".star-rate i").removeClass("on bi-star-fill").addClass("bi-star");
    $f.find(".form-msg").hide().html('<div class="alert alert-success rounded-4 mt-3 mb-0"><i class="bi bi-check-circle-fill"></i> Thank you! Your message has been received.</div>').fadeIn(400);
    renderFeedback();
  });
  function renderFeedback() {
    var $w = $("#feedbackList"); if (!$w.length) return;
    var all = JSON.parse(localStorage.getItem("bob_feedback") || "[]");
    if (!all.length) { $w.html('<p class="text-muted">No feedback yet — be the first to share!</p>'); return; }
    $w.html(all.slice(0, 6).map(function (f) {
      var s = ""; for (var i = 0; i < 5; i++) s += '<i class="bi bi-star' + (i < (f.rating || 0) ? "-fill text-coral" : "") + '"></i>';
      return '<div class="beach-card p-3 mb-3"><div class="d-flex justify-content-between flex-wrap"><b class="text-break">' + $("<i>").text(f.name).html() + "</b><small>" + s + '</small></div><p class="m-0 mt-2">' + $("<i>").text(f.message).html() + '</p><small class="text-muted">' + f.date + "</small></div>";
    }).join(""));
  }
  renderFeedback();
});
